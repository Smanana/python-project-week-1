#The progam the requires user to input test scores inorder to get the average

student_name = input("Enter your name: \n") 
student_surname = input("Enter your surname: \n")
student_age = int(input("Enter your age: \n"))
student_number = input("Enter your student number: \n")
print("\n")
print("-----PlEASE ENTER YOUR RESULTS-----")
print("\n")

maths = int(input("Enter  Maths result: \n"))
science= int(input("Enter  Science result: \n"))
engineering = int(input("Enter  Engineering result: \n"))
technology = int(input("Enter  Technology result: \n"))


total = maths + science + engineering + technology
marks_entered = 4
average = int(total / marks_entered)
print("Your Average is: ",average)   

print("\n")

student_name = input("Enter your name: \n") 
student_surname = input("Enter your surname: \n")
student_age = int(input("Enter your age: \n"))
student_number = input("Enter your student number: \n")
print("\n")
print("-----PlEASE ENTER YOUR RESULTS-----")
print("\n")

maths = int(input("Enter  Maths result: \n"))
science= int(input("Enter  Science result: \n"))
engineering = int(input("Enter  Engineering result: \n"))
technology = int(input("Enter  Technology result: \n"))


total = maths + science + engineering + technology
marks_entered = 4
average = int(total / marks_entered)
print("Your Average is: ",average)

student_name = input("Enter your name: \n") 
student_surname = input("Enter your surname: \n")
student_age = int(input("Enter your age: \n"))
student_number = input("Enter your student number: \n")
print("\n")
print("-----PlEASE ENTER YOUR RESULTS-----")
print("\n")

maths = int(input("Enter  Maths result: \n"))
science= int(input("Enter  Science result: \n"))
engineering = int(input("Enter  Engineering result: \n"))
technology = int(input("Enter  Technology result: \n"))


total = maths + science + engineering + technology
marks_entered = 4
average = int(total / marks_entered)
print("Your Average is: ",average)

